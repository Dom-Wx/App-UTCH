import { useRouter } from "expo-router";
import { useState } from "react";
import { ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import Boton from "../components/Boton";
import Encabezado from "../components/Encabezado";
import { colores } from "../constants/colores";
import { useSesion } from "../context/SesionContext";

export default function Login() {
  const router = useRouter();
  const { iniciarSesion } = useSesion();
  const [matricula, setMatricula] = useState("");
  const [password, setPassword] = useState("");
  const [aviso, setAviso] = useState("");
  const [cargando, setCargando] = useState(false);

  async function continuar() {
    setAviso("");
    setCargando(true);
    const res = await iniciarSesion(matricula, password);
    setCargando(false);

    if (!res.ok) {
      setAviso(res.error);
      return;
    }

    router.replace("/");
  }

  return (
    <ScrollView style={styles.pantalla} keyboardShouldPersistTaps="handled">
      <Encabezado titulo="Iniciar sesión" onAtras={() => router.back()} />
      <View style={styles.contenido}>
        <Text style={styles.titulo}>Bienvenido a UTCH ParkMate</Text>
        <Text style={styles.descripcion}>
          Ingresa tu matrícula y contraseña registrada para acceder a tu
          credencial y consultar disponibilidad.
        </Text>

        <Text style={styles.etiqueta}>Matrícula o No. Empleado</Text>
        <TextInput
          value={matricula}
          onChangeText={(texto) => {
            setMatricula(texto);
            setAviso("");
          }}
          placeholder="Ej. 1221100456"
          autoCapitalize="characters"
          autoCorrect={false}
          style={styles.entrada}
          accessibilityLabel="Matrícula"
        />

        <Text style={styles.etiqueta}>Contraseña</Text>
        <TextInput
          value={password}
          onChangeText={(texto) => {
            setPassword(texto);
            setAviso("");
          }}
          placeholder="Tu contraseña"
          secureTextEntry
          returnKeyType="done"
          onSubmitEditing={continuar}
          style={styles.entrada}
          accessibilityLabel="Contraseña"
        />

        {aviso !== "" && <Text style={styles.aviso}>{aviso}</Text>}

        <View style={styles.botones}>
          <Boton
            texto={cargando ? "Verificando..." : "Entrar"}
            onPress={cargando ? () => {} : continuar}
          />
          <Boton
            texto="¿No tienes cuenta? Crear cuenta UTCH"
            tipo="secundario"
            onPress={() => router.replace("/registro")}
          />
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  pantalla: {
    flex: 1,
    backgroundColor: colores.fondo,
  },
  contenido: {
    padding: 20,
  },
  titulo: {
    fontSize: 26,
    fontWeight: "bold",
    color: colores.texto,
  },
  descripcion: {
    marginTop: 8,
    marginBottom: 20,
    fontSize: 16,
    lineHeight: 23,
    color: colores.texto,
  },
  etiqueta: {
    marginTop: 12,
    marginBottom: 8,
    fontSize: 16,
    fontWeight: "bold",
    color: colores.texto,
  },
  entrada: {
    minHeight: 50,
    paddingHorizontal: 14,
    borderWidth: 1,
    borderColor: colores.estructura,
    borderRadius: 10,
    backgroundColor: colores.blanco,
    color: colores.texto,
    fontSize: 17,
  },
  aviso: {
    marginTop: 14,
    padding: 12,
    borderRadius: 8,
    backgroundColor: "#FEE2E2",
    color: colores.rojo,
    fontSize: 14,
    fontWeight: "bold",
  },
  botones: {
    marginTop: 14,
  },
});
